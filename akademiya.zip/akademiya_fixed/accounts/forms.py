from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm
from .models import User


class RegisterForm(UserCreationForm):
    name = forms.CharField(
        max_length=150,
        label="To'liq ism",
        widget=forms.TextInput(attrs={"placeholder": "Ismingiz va familiyangiz", "class": "form-control form-control-lg"}),
    )
    email = forms.EmailField(
        label="Email manzil",
        widget=forms.EmailInput(attrs={"placeholder": "email@example.com", "class": "form-control form-control-lg"}),
    )
    password1 = forms.CharField(
        label="Parol",
        widget=forms.PasswordInput(attrs={"placeholder": "Kamida 8 ta belgi", "class": "form-control form-control-lg", "id": "id_password1"}),
    )
    password2 = forms.CharField(
        label="Parolni tasdiqlang",
        widget=forms.PasswordInput(attrs={"placeholder": "Parolni qayta kiriting", "class": "form-control form-control-lg", "id": "id_password2"}),
    )

    class Meta:
        model = User
        fields = ("name", "email", "password1", "password2")

    def clean_email(self):
        email = self.cleaned_data.get("email")
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("Bu email allaqachon ro'yxatdan o'tgan")
        return email


class LoginForm(forms.Form):
    email = forms.EmailField(
        label="Email manzil",
        widget=forms.EmailInput(attrs={"placeholder": "email@example.com", "class": "form-control form-control-lg", "autofocus": True}),
    )
    password = forms.CharField(
        label="Parol",
        widget=forms.PasswordInput(attrs={"placeholder": "Parolingiz", "class": "form-control form-control-lg", "id": "id_password"}),
    )

    def clean(self):
        cleaned_data = super().clean()
        email = cleaned_data.get("email")
        password = cleaned_data.get("password")
        if email and password:
            user = authenticate(username=email, password=password)
            if user is None:
                raise forms.ValidationError("Email yoki parol noto'g'ri")
            if not user.is_active:
                raise forms.ValidationError("Hisob faolsizlantirilgan")
            cleaned_data["user"] = user
        return cleaned_data


class ProfileForm(forms.ModelForm):
    name = forms.CharField(
        label="To'liq ism",
        widget=forms.TextInput(attrs={"class": "form-control"}),
    )
    bio = forms.CharField(
        label="Bio",
        required=False,
        widget=forms.Textarea(attrs={"class": "form-control", "rows": 3}),
    )
    avatar = forms.ImageField(
        label="Avatar",
        required=False,
        widget=forms.FileInput(attrs={"class": "form-control"}),
    )

    class Meta:
        model = User
        fields = ("name", "bio", "avatar")
