from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
import json
from .models import CodeSubmission, CodeChallenge, LANGUAGE_CHOICES


@login_required
def editor_home(request):
    challenges = CodeChallenge.objects.filter(is_active=True)
    my_submissions = CodeSubmission.objects.filter(user=request.user).order_by("-updated_at")[:10]
    public_submissions = CodeSubmission.objects.filter(is_public=True).exclude(user=request.user).select_related("user").order_by("-created_at")[:10]

    return render(request, "code_editor/home.html", {
        "challenges": challenges,
        "my_submissions": my_submissions,
        "public_submissions": public_submissions,
        "languages": LANGUAGE_CHOICES,
    })


@login_required
def new_submission(request):
    challenge_id = request.GET.get("challenge")
    challenge = None
    starter_code = ""
    language = "python"

    if challenge_id:
        challenge = get_object_or_404(CodeChallenge, id=challenge_id, is_active=True)
        starter_code = challenge.starter_code
        language = challenge.language

    if request.method == "POST":
        title = request.POST.get("title", "Mening kodum")
        language = request.POST.get("language", "python")
        code = request.POST.get("code", "")
        is_public = request.POST.get("is_public") == "on"
        status = request.POST.get("status", "draft")

        submission = CodeSubmission.objects.create(
            user=request.user,
            challenge=challenge,
            title=title,
            language=language,
            code=code,
            is_public=is_public,
            status=status,
        )
        messages.success(request, "Kod muvaffaqiyatli saqlandi!")
        return redirect("view_submission", submission_id=submission.id)

    return render(request, "code_editor/editor.html", {
        "challenge": challenge,
        "starter_code": starter_code,
        "language": language,
        "languages": LANGUAGE_CHOICES,
        "submission": None,
    })


@login_required
def edit_submission(request, submission_id):
    submission = get_object_or_404(CodeSubmission, id=submission_id, user=request.user)

    if request.method == "POST":
        submission.title = request.POST.get("title", submission.title)
        submission.language = request.POST.get("language", submission.language)
        submission.code = request.POST.get("code", submission.code)
        submission.is_public = request.POST.get("is_public") == "on"
        submission.status = request.POST.get("status", submission.status)
        submission.save()
        messages.success(request, "Kod yangilandi!")
        return redirect("view_submission", submission_id=submission.id)

    return render(request, "code_editor/editor.html", {
        "submission": submission,
        "language": submission.language,
        "languages": LANGUAGE_CHOICES,
        "challenge": submission.challenge,
    })


@login_required
def view_submission(request, submission_id):
    submission = get_object_or_404(CodeSubmission, id=submission_id)
    if not submission.is_public and submission.user != request.user:
        messages.error(request, "Bu kod ommaviy emas.")
        return redirect("editor_home")
    return render(request, "code_editor/view.html", {"submission": submission})


@login_required
def delete_submission(request, submission_id):
    submission = get_object_or_404(CodeSubmission, id=submission_id, user=request.user)
    submission.delete()
    messages.success(request, "Kod o'chirildi.")
    return redirect("editor_home")


@login_required
def challenge_detail(request, challenge_id):
    challenge = get_object_or_404(CodeChallenge, id=challenge_id, is_active=True)
    my_submission = CodeSubmission.objects.filter(user=request.user, challenge=challenge).first()
    return render(request, "code_editor/challenge.html", {
        "challenge": challenge,
        "my_submission": my_submission,
        "languages": LANGUAGE_CHOICES,
    })
