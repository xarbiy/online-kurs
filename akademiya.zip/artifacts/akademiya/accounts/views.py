from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.http import require_http_methods
from .forms import RegisterForm, LoginForm, ProfileForm
from .models import User
from quizzes.models import QuizResult
from courses.models import Course, Enrollment, Subject


def home(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    context = {
        "total_courses": Course.objects.filter(is_active=True).count(),
        "total_users": User.objects.filter(is_active=True).count(),
        "subjects_list": Subject.objects.all().order_by("order"),
    }
    return render(request, "home.html", context)


@require_http_methods(["GET", "POST"])
def register_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user, backend="django.contrib.auth.backends.ModelBackend")
            messages.success(request, f"Xush kelibsiz, {user.get_short_name()}! Muvaffaqiyatli ro'yxatdan o'tdingiz.")
            return redirect("dashboard")
    else:
        form = RegisterForm()
    return render(request, "accounts/register.html", {"form": form})


@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            user = form.cleaned_data["user"]
            login(request, user, backend="django.contrib.auth.backends.ModelBackend")
            next_url = request.GET.get("next", "dashboard")
            messages.success(request, f"Xush kelibsiz, {user.get_short_name()}!")
            return redirect(next_url)
    else:
        form = LoginForm()
    return render(request, "accounts/login.html", {"form": form})


def logout_view(request):
    logout(request)
    messages.info(request, "Tizimdan muvaffaqiyatli chiqdingiz.")
    return redirect("home")


@login_required
def dashboard_view(request):
    user = request.user
    enrollments = Enrollment.objects.filter(user=user).select_related("course")
    recent_results = QuizResult.objects.filter(user=user).select_related("quiz").order_by("-completed_at")[:5]
    total_results = QuizResult.objects.filter(user=user)
    avg_score = 0
    if total_results.exists():
        avg_score = sum(r.score for r in total_results) / total_results.count()

    context = {
        "enrollments": enrollments,
        "recent_results": recent_results,
        "total_quizzes": total_results.count(),
        "avg_score": round(avg_score, 1),
        "enrolled_count": enrollments.count(),
    }
    return render(request, "dashboard.html", context)


@login_required
def profile_view(request):
    if request.method == "POST":
        form = ProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profil muvaffaqiyatli yangilandi.")
            return redirect("profile")
    else:
        form = ProfileForm(instance=request.user)
    return render(request, "accounts/profile.html", {"form": form})
