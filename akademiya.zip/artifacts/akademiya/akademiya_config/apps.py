from django.apps import AppConfig


class AkademiyaConfig(AppConfig):
    name = "akademiya_config"
    verbose_name = "Akademiya Config"
